# Reno AI Live - Proguard Rules
-keep class com.reno.ailive.data.** { *; }
-keep class com.reno.ailive.ai.** { *; }
-keep class com.google.mlkit.** { *; }
-keepclassmembers class * {
    @com.google.gson.annotations.SerializedName <fields>;
}
