package com.reno.ailive.service

import android.annotation.SuppressLint
import android.app.Notification
import android.app.PendingIntent
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.reno.ailive.MainActivity
import com.reno.ailive.R
import com.reno.ailive.RenoApp
import com.reno.ailive.ai.AiEngineClient
import com.reno.ailive.capture.ScreenCaptureManager
import com.reno.ailive.data.HistoryEntity
import com.reno.ailive.ocr.OcrProcessor
import com.reno.ailive.ui.theme.CrimsonRed
import kotlinx.coroutines.*

class FloatingOverlayService : LifecycleService(), SavedStateRegistryOwner, ViewModelStoreOwner {

    companion object {
        const val ACTION_START = "ACTION_START"
        const val ACTION_STOP = "ACTION_STOP"
        const val EXTRA_RESULT_CODE = "EXTRA_RESULT_CODE"
        const val EXTRA_RESULT_DATA = "EXTRA_RESULT_DATA"
        var isRunning = false
            private set
    }

    // SavedState & ViewModelStore support for Compose inside WindowManager
    private val savedStateRegistryController = SavedStateRegistryController.create(this)
    override val savedStateRegistry: SavedStateRegistry get() = savedStateRegistryController.savedStateRegistry
    override val viewModelStore: ViewModelStore = ViewModelStore()

    private lateinit var windowManager: WindowManager
    private var floatingView: ComposeView? = null
    private var screenCaptureManager: ScreenCaptureManager? = null
    private val ocrProcessor = OcrProcessor()
    private val aiClient = AiEngineClient()
    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())

    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f

    // UI state observable by Compose
    private val isHudOpen = mutableStateOf(false)
    private val isAnalyzing = mutableStateOf(false)
    private val currentResult = mutableStateOf<AiEngineClient.AiResponse?>(null)

    override fun onCreate() {
        super.onCreate()
        savedStateRegistryController.performRestore(null)
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        isRunning = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        when (intent?.action) {
            ACTION_START -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                val data: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(EXTRA_RESULT_DATA)
                }

                if (data != null) {
                    startForegroundWithMediaProjection()
                    screenCaptureManager = ScreenCaptureManager(this, resultCode, data)
                    initFloatingOverlay()
                }
            }
            ACTION_STOP -> {
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun startForegroundWithMediaProjection() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // Android 10 to Android 15 Foreground Service MediaProjection
            startForeground(
                1001,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(1001, notification)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun initFloatingOverlay() {
        if (floatingView != null) return

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 300
        }

        floatingView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@FloatingOverlayService)
            setViewTreeViewModelStoreOwner(this@FloatingOverlayService)
            setViewTreeSavedStateRegistryOwner(this@FloatingOverlayService)

            setContent {
                FloatingBubbleAndHud(
                    isHudOpen = isHudOpen.value,
                    isAnalyzing = isAnalyzing.value,
                    result = currentResult.value,
                    onTriggerSolve = { triggerScreenReading() },
                    onCloseHud = { isHudOpen.value = false },
                    onCopy = { text -> copyToClipboard(text) }
                )
            }
        }

        floatingView?.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - initialTouchX).toInt()
                    params.y = initialY + (event.rawY - initialTouchY).toInt()
                    windowManager.updateViewLayout(view, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val deltaX = Math.abs(event.rawX - initialTouchX)
                    val deltaY = Math.abs(event.rawY - initialTouchY)
                    if (deltaX < 15 && deltaY < 15) {
                        triggerScreenReading()
                    }
                    true
                }
                else -> false
            }
        }

        windowManager.addView(floatingView, params)
    }

    private fun triggerScreenReading() {
        if (isAnalyzing.value) return
        isAnalyzing.value = true
        isHudOpen.value = true

        serviceScope.launch {
            try {
                // 1. Capture screen buffer
                val bitmap = screenCaptureManager?.captureScreen()
                if (bitmap == null) {
                    Toast.makeText(this@FloatingOverlayService, "Gagal menangkap layar", Toast.LENGTH_SHORT).show()
                    isAnalyzing.value = false
                    return@launch
                }

                // 2. Perform On-device ML Kit OCR
                val extractedText = ocrProcessor.recognizeText(bitmap)

                // 3. Query AI Engine (Gemini Flash)
                val apiKey = RenoApp.instance.secureStorage.getApiKey()
                val provider = RenoApp.instance.secureStorage.getProvider()
                val response = aiClient.solveProblem(
                    ocrText = extractedText,
                    bitmap = bitmap,
                    provider = provider,
                    apiKey = apiKey
                )

                currentResult.value = response

                // 4. Save to Room database
                RenoApp.instance.database.historyDao().insert(
                    HistoryEntity(
                        question = response.question,
                        bestAnswer = response.bestAnswer,
                        explanation = response.explanation,
                        confidence = response.confidence,
                        tags = response.tags.joinToString(","),
                        timestamp = System.currentTimeMillis()
                    )
                )

                // 5. Auto copy if enabled
                if (RenoApp.instance.secureStorage.isAutoCopyEnabled()) {
                    copyToClipboard(response.bestAnswer)
                }

            } catch (e: Exception) {
                currentResult.value = AiEngineClient.AiResponse(
                    question = "Screen Reading Error",
                    bestAnswer = "Error",
                    explanation = e.localizedMessage ?: "Gagal memproses layar.",
                    confidence = 0,
                    keySteps = listOf("Periksa koneksi internet", "Pastikan API Key sudah diatur"),
                    tags = listOf("Error")
                )
            } finally {
                isAnalyzing.value = false
            }
        }
    }

    private fun copyToClipboard(text: String) {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("Reno AI Live Answer", text)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(this, "Tersalin: $text", Toast.LENGTH_SHORT).show()
    }

    private fun buildNotification(): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, RenoApp.OVERLAY_CHANNEL_ID)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(getString(R.string.notification_text))
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        screenCaptureManager?.release()
        if (floatingView != null) {
            windowManager.removeView(floatingView)
            floatingView = null
        }
        viewModelStore.clear()
        isRunning = false
    }

    override fun onBind(intent: Intent): IBinder? {
        super.onBind(intent)
        return null
    }
}

@Composable
fun FloatingBubbleAndHud(
    isHudOpen: Boolean,
    isAnalyzing: Boolean,
    result: AiEngineClient.AiResponse?,
    onTriggerSolve: () -> Unit,
    onCloseHud: () -> Unit,
    onCopy: (String) -> Unit
) {
    Column(
        modifier = Modifier.wrapContentSize(),
        horizontalAlignment = Alignment.End
    ) {
        // Floating Bubble Pill
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = Color(0xFF09090B),
            shadowElevation = 8.dp,
            modifier = Modifier
                .border(1.5.dp, CrimsonRed, RoundedCornerShape(24.dp))
                .clickable { onTriggerSolve() }
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(CrimsonRed)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isAnalyzing) "Memindai..." else "Tebak Layar",
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Expandable HUD Window
        if (isHudOpen && result != null) {
            Surface(
                modifier = Modifier
                    .width(320.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .border(1.dp, Color(0xFF27272A), RoundedCornerShape(16.dp)),
                color = Color(0xFF0A0A0C),
                shadowElevation = 16.dp
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "RENO AI LIVE",
                                color = CrimsonRed,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "· ${result.confidence}% Confident",
                                color = Color(0xFFA1A1AA),
                                fontSize = 11.sp
                            )
                        }
                        IconButton(onClick = onCloseHud, modifier = Modifier.size(24.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Best Answer Box
                    Surface(
                        color = Color(0xFF141417),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, CrimsonRed.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "JAWABAN TERBAIK",
                                color = CrimsonRed,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = result.bestAnswer,
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Explanation
                    Text(
                        text = result.explanation,
                        color = Color(0xFFD4D4D8),
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Actions
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        Button(
                            onClick = { onCopy(result.bestAnswer) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF18181B),
                                contentColor = Color.White
                            ),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "Copy", modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Salin", fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}
