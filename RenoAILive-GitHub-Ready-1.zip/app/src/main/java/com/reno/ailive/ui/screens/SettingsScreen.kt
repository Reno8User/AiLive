package com.reno.ailive.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.reno.ailive.RenoApp
import com.reno.ailive.ui.theme.*

@Composable
fun SettingsScreen() {
    val context = LocalContext.current
    val storage = RenoApp.instance.secureStorage

    var apiKey by remember { mutableStateOf(storage.getApiKey()) }
    var selectedProvider by remember { mutableStateOf(storage.getProvider()) }
    var autoCopy by remember { mutableStateOf(storage.isAutoCopyEnabled()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp)
    ) {
        Text(
            text = "KONFIGURASI MESIN AI",
            color = Color.White,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )

        Spacer(modifier = Modifier.height(20.dp))

        // API Key input
        OutlinedTextField(
            value = apiKey,
            onValueChange = { apiKey = it },
            label = { Text("AI API Key (Terenkripsi di Keystore)") },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = CrimsonRed,
                unfocusedBorderColor = BorderDark,
                focusedLabelColor = CrimsonRed,
                unfocusedLabelColor = TextMuted,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            )
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                storage.saveApiKey(apiKey)
                storage.saveProvider(selectedProvider)
                storage.setAutoCopy(autoCopy)
                Toast.makeText(context, "Pengaturan berhasil disimpan di Keystore!", Toast.LENGTH_SHORT).show()
            },
            colors = ButtonDefaults.buttonColors(containerColor = CrimsonRed),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Simpan Pengaturan")
        }
    }
}
