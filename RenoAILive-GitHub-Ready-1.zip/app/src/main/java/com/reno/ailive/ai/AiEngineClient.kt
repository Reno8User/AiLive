package com.reno.ailive.ai

import android.graphics.Bitmap
import android.util.Base64
import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

class AiEngineClient {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .build()

    private val gson = Gson()
    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    data class AiResponse(
        @SerializedName("question") val question: String = "",
        @SerializedName("bestAnswer") val bestAnswer: String = "",
        @SerializedName("explanation") val explanation: String = "",
        @SerializedName("confidence") val confidence: Int = 90,
        @SerializedName("keySteps") val keySteps: List<String> = emptyList(),
        @SerializedName("codeSnippet") val codeSnippet: String? = null,
        @SerializedName("tags") val tags: List<String> = emptyList()
    )

    suspend fun solveProblem(
        ocrText: String,
        bitmap: Bitmap?,
        provider: String,
        apiKey: String
    ): AiResponse = withContext(Dispatchers.IO) {
        val prompt = """
            You are Reno AI Live, an ultra-fast exam, code, and screen question solver.
            Analyze this screen content and OCR text:
            "$ocrText"

            Provide STRICT valid JSON:
            {
              "question": "question extracted from screen",
              "bestAnswer": "Direct concise answer (e.g. 'B. Oksigen' or 'x = 5')",
              "explanation": "Clear derivation or justification",
              "confidence": 95,
              "keySteps": ["Step 1", "Step 2"],
              "tags": ["Subject", "Topic"]
            }
        """.trimIndent()

        val endpoint = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey"

        val requestJson = """
            {
              "contents": [{
                "parts": [
                  {"text": ${gson.toJson(prompt)}}
                ]
              }],
              "generationConfig": {
                "responseMimeType": "application/json"
              }
            }
        """.trimIndent()

        val request = Request.Builder()
            .url(endpoint)
            .post(requestJson.toRequestBody(jsonMediaType))
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw Exception("HTTP ${response.code}: ${response.body?.string()}")
            }
            val bodyString = response.body?.string() ?: ""
            val root = gson.fromJson(bodyString, Map::class.java)
            val candidates = root["candidates"] as? List<Map<String, Any>>
            val content = candidates?.firstOrNull()?.get("content") as? Map<String, Any>
            val parts = content?.get("parts") as? List<Map<String, Any>>
            val textJson = parts?.firstOrNull()?.get("text") as? String ?: "{}"

            gson.fromJson(textJson, AiResponse::class.java)
        }
    }
}
