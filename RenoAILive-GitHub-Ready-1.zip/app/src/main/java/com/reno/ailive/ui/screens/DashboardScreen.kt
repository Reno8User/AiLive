package com.reno.ailive.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.reno.ailive.ui.theme.*

@Composable
fun DashboardScreen(
    isServiceRunning: Boolean,
    hasOverlayPermission: Boolean,
    onRequestOverlayPermission: () -> Unit,
    onToggleService: (Boolean) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp)
    ) {
        // App Title
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "RENO AI LIVE",
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Screen OCR & Instant AI Solver",
                    color = TextMuted,
                    fontSize = 12.sp
                )
            }
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(if (isServiceRunning) CrimsonRed else Color(0xFF3F3F46))
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Main Service Controller Card
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, if (isServiceRunning) CrimsonRed else BorderDark, RoundedCornerShape(16.dp)),
            color = SurfaceDark,
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Floating Overlay",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isServiceRunning) "Aktif di atas semua aplikasi" else "Layanan berhenti",
                            color = if (isServiceRunning) CrimsonRed else TextMuted,
                            fontSize = 13.sp
                        )
                    }
                    Switch(
                        checked = isServiceRunning,
                        onCheckedChange = { onToggleService(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = CrimsonRed,
                            uncheckedThumbColor = TextMuted,
                            uncheckedTrackColor = Color(0xFF27272A)
                        )
                    )
                }

                if (!hasOverlayPermission) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = onRequestOverlayPermission,
                        colors = ButtonDefaults.buttonColors(containerColor = CrimsonRed),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Izinkan Tampilkan Di Atas Aplikasi Lain")
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // System Permissions Check
        Text(
            text = "STATUS SISTEM & IZIN",
            color = TextSubtle,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )
        Spacer(modifier = Modifier.height(8.dp))

        PermissionItem(title = "Display over other apps (Overlay)", granted = hasOverlayPermission)
        Spacer(modifier = Modifier.height(6.dp))
        PermissionItem(title = "MediaProjection (Rekam Layar)", granted = isServiceRunning)
        Spacer(modifier = Modifier.height(6.dp))
        PermissionItem(title = "On-Device ML Kit OCR", granted = true)
        Spacer(modifier = Modifier.height(6.dp))
        PermissionItem(title = "Keystore Hardware AES-256", granted = true)
    }
}

@Composable
fun PermissionItem(title: String, granted: Boolean) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, BorderDark, RoundedCornerShape(10.dp)),
        color = CardBackground,
        shape = RoundedCornerShape(10.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = title, color = Color.White, fontSize = 13.sp)
            Icon(
                imageVector = if (granted) Icons.Default.CheckCircle else Icons.Default.Warning,
                contentDescription = null,
                tint = if (granted) CrimsonRed else TextSubtle,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}
