package com.reno.ailive.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "solution_history")
data class HistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val question: String,
    val bestAnswer: String,
    val explanation: String,
    val confidence: Int,
    val tags: String,
    val timestamp: Long = System.currentTimeMillis()
)
