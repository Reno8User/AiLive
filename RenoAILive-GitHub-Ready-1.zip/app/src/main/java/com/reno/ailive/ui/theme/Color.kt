package com.reno.ailive.ui.theme

import androidx.compose.ui.graphics.Color

val BlackBackground = Color(0xFF050505)
val SurfaceDark = Color(0xFF0F0F12)
val CardBackground = Color(0xFF141418)
val BorderDark = Color(0xFF27272A)

val CrimsonRed = Color(0xFFFF2A3B)
val CrimsonRedDim = Color(0xFF991B1B)
val CrimsonRedGlow = Color(0x33FF2A3B)

val TextWhite = Color(0xFFF4F4F5)
val TextMuted = Color(0xFFA1A1AA)
val TextSubtle = Color(0xFF71717A)
