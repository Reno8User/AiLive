package com.reno.ailive.data

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class SecureStorage(context: Context) {

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val sharedPreferences = EncryptedSharedPreferences.create(
        context,
        "reno_ai_live_secure_prefs",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun saveApiKey(key: String) {
        sharedPreferences.edit().putString("ai_api_key", key).apply()
    }

    fun getApiKey(): String {
        return sharedPreferences.getString("ai_api_key", "") ?: ""
    }

    fun saveProvider(provider: String) {
        sharedPreferences.edit().putString("ai_provider", provider).apply()
    }

    fun getProvider(): String {
        return sharedPreferences.getString("ai_provider", "gemini") ?: "gemini"
    }

    fun setAutoCopy(enabled: Boolean) {
        sharedPreferences.edit().putBoolean("auto_copy", enabled).apply()
    }

    fun isAutoCopyEnabled(): Boolean {
        return sharedPreferences.getBoolean("auto_copy", true)
    }
}
