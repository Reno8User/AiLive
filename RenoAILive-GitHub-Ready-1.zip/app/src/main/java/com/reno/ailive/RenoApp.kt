package com.reno.ailive

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.reno.ailive.data.AppDatabase
import com.reno.ailive.data.SecureStorage

class RenoApp : Application() {

    companion object {
        lateinit var instance: RenoApp
            private set
        const val OVERLAY_CHANNEL_ID = "reno_floating_overlay_channel"
    }

    val database by lazy { AppDatabase.getDatabase(this) }
    val secureStorage by lazy { SecureStorage(this) }

    override fun onCreate() {
        super.onCreate()
        instance = this
        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                OVERLAY_CHANNEL_ID,
                getString(R.string.channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.channel_desc)
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }
}
